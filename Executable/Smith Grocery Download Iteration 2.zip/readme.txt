The default user is the Admin
The Admin's Employee ID is 0 and the default password is system.
When logging in for the first time enter
0
for the Employee ID
system
for the Password